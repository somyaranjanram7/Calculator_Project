#include <gtk/gtk.h>


void
on_BackSpace_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Clear_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Clr_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Sign_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Div_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Nine_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Eight_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Seven_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Four_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Six_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Mul_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Sub_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Three_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Two_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_One_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Zero_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Dot_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Equal_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Add_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Five_clicked                        (GtkButton       *button,
                                        gpointer         user_data);
